package org.forgerock.openam.auth.Utility;

import java.net.URI;
import java.net.http.HttpRequest;

public class HttpConnection {

    public static HttpRequest getRequest(String url){
        HttpRequest request = HttpRequest.newBuilder()
			        .uri(URI.create(url))
			        .header("X-OpenIDM-Username", "openidm-admin")
			        .header("X-OpenIDM-Password", "openidm-admin")
		            .GET()
			        .build();
        return request;
    }
    
}
