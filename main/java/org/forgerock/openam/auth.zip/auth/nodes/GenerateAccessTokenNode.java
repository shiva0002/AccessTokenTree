package org.forgerock.openam.auth.nodes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.forgerock.json.JsonValue;
import org.forgerock.openam.annotations.sm.Attribute;
import org.forgerock.openam.auth.node.api.AbstractDecisionNode;
import org.forgerock.openam.auth.node.api.Action;
import org.forgerock.openam.auth.node.api.Node;
import org.forgerock.openam.auth.node.api.TreeContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.assistedinject.Assisted;


@Node.Metadata(outcomeProvider = AbstractDecisionNode.OutcomeProvider.class,
                configClass = GenerateAccessTokenNode.Config.class)
public class GenerateAccessTokenNode extends AbstractDecisionNode {

    final Map<String,String> params = new HashMap<String,String>();
    
	public interface Config {
        @Attribute(order = 100)
        default String variable() { return "variable"; }

        @Attribute(order = 200)
        default String prompt() { return "Prompt"; }
        
        @Attribute(order=300)
        default String urlValue() {return "http://openam.example.com:9090/openam/oauth2/realms/root/realms/demo/access_token"; }
        @Attribute(order=400)
        default String clientId()
        {
        	return "ClientId";
        }
        @Attribute(order=500)
        default String clientSecret()
        {
        	return "ClientSecret";
        }
    }
	
	private static final String BUNDLE = "org/forgerock/openam/auth/nodes/GenerateAccessTokenNode";
	private final GenerateAccessTokenNode.Config config;
    private final Logger logger = LoggerFactory.getLogger("amAuth");
    
	
	@Inject
    public GenerateAccessTokenNode(@Assisted GenerateAccessTokenNode.Config config) {
        this.config = config;
    }

    @SuppressWarnings("deprecation")
	@Override
	public Action process(TreeContext context) {
	    
        System.out.println("Generate Access Token Node");
        
        String authCode = context.sharedState.get("authorizationCode").asString();
        System.out.println("Authorization Code: "+authCode);
        logger.info("Auth Code is: "+ authCode);
		// Access the shared state
        JsonValue sharedState = context.sharedState;   

		params.put("url", this.config.urlValue());
        params.put("clientId", this.config.clientId());
        params.put("clientSecret", this.config.clientSecret());
        params.put("grantType", "authorization_code");
		
		// String url = this.config.urlValue();
        // String clientId = this.config.clientId();
        // String clientSecret = this.config.clientSecret();
        String authorization = params.get("clientId") + ":" + params.get("clientSecret");
        String encodedAuthorization = Base64.getEncoder().encodeToString(authorization.getBytes(StandardCharsets.UTF_8));
        // String grantType = "authorization_code";
        String code = authCode;
        String accessToken = "";
        try {
            URL endpoint = new URL(params.get("url"));
            HttpURLConnection connection = (HttpURLConnection) endpoint.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Authorization", "Basic " + encodedAuthorization);
            connection.setDoOutput(true);

            String data = "grant_type=" + params.get("grantType") + "&code=" + code;
            byte[] postData = data.getBytes(StandardCharsets.UTF_8);
            connection.getOutputStream().write(postData);

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
           
            System.out.println("Response: " + response.toString());
            
            int startIndex = response.toString().indexOf("\"access_token\":\"");
            if (startIndex != -1) {
                startIndex += 16; // Move to the beginning of the actual access token
                int endIndex = response.toString().indexOf("\"", startIndex);
                if (endIndex != -1) {
                     accessToken = response.toString().substring(startIndex, endIndex);
                }
            }
            else {
            	accessToken = "";
            }

            if(accessToken.isEmpty()){
                logger.info("Invalid Access Token");
                return goTo(false).build();
            }
			
            // Store data in the shared state
            sharedState.put("accessToken", accessToken);
            
			System.out.println("Access Token: " + accessToken);
			connection.disconnect();
			
            
        } catch (Exception e) {
        	e.printStackTrace();
            logger.info("Invalid Access Token");
            return goTo(false).build();
        }
        
        return goTo(true).putSessionProperty("access_token", accessToken).replaceSharedState(sharedState).build();
        
	}
}
